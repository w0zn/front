# Memory Game

A simple memory game built with Vue.js and Vite. The game challenges players to match pairs of cards while keeping track of time and score.

## Table of Contents

- [Features](#features)
- [Installation](#installation)
- [Usage](#usage)
- [Project Structure](#project-structure)
- [Components Overview](#components-overview)
- [License](#license)

## Features

- Dynamic card matching gameplay
- Difficulty selection
- Scoreboard and game history
- Responsive design

## Installation

To get started with the project, follow these steps:

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/mem-game.git
   cd mem-game
   ```

2. Install the dependencies:
   ```bash
   bun install
   ```

3. Start the development server:
   ```bash
   bun dev
   ```

4. Open your browser and navigate to `http://localhost:3000` to view the game.

## Usage

- Select the difficulty level from the dropdown menu.
- Click on the "Zagraj" button to start the game.
- Match pairs of cards before time runs out.
- View your score and game history after finishing the game.

## Components Overview

- **`choose-difficulty.vue`**: Allows users to select the difficulty level of the game.
- **`card.vue`**: Represents a single card in the game, handling its front and back images.
- **`root.vue`**: The main game component that manages the game state and transitions between pages.
- **`game.vue`**: The game page that displays the scoreboard, card grid, and controls.
- **`start.vue`**: The starting page where users can select difficulty and view game history.
- **`GameHistory.vue`**: Displays the history of past games.

## License

This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.