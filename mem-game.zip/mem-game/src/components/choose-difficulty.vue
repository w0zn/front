<template>
  <div>
    <label for="difficulty">Wybierz Poziom Trudności:</label>
    <select v-model="selectedDifficulty" id="difficulty" @change="updateDifficulty">
      <option v-for="level in difficultyLevels" :key="level" :value="level">
        {{ level }}
      </option>
    </select>
    <p>Wybrany Poziom Trudności: {{ selectedDifficulty }}</p>
  </div>
</template>

<script>
import { mapMutations } from 'vuex';

export default {
  data() {
    return {
      selectedDifficulty: 'Easy', // Default difficulty
      difficultyLevels: ['Easy', 'Medium', 'Hard'], // Available difficulty levels
    };
  },
  methods: {
    ...mapMutations(['setDifficulty']), // Map the mutation
    updateDifficulty() {
      this.setDifficulty(this.selectedDifficulty); // Commit the mutation with the selected difficulty
    }
  },
  watch: {
    // Watch for changes in the Vuex store difficulty state
    difficulty() {
      this.selectedDifficulty = this.difficulty; // Update local state if Vuex state changes
    }
  },
  computed: {
    difficulty() {
      return this.$store.getters.difficulty; // Access the difficulty from Vuex store
    }
  }
};
</script>

<style scoped>
/* Dodano style dla etykiety i selektora */
label {
  font-weight: bold;
  margin-right: 10px;
}

select {
  padding: 5px;
  border-radius: 4px;
  border: 1px solid #ccc;
}

p {
  margin-top: 10px;
  font-style: italic;
  color: #555;
}
</style>
