<template>
  <div class="game-history">
    <h2>Historia Gier</h2>
    <table>
      <thead>
        <tr>
          <th>Data</th>
          <th>Liczba prób</th>
          <th>Czas gry</th>
          <th>Tryb</th>
          <th>Wynik</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(game, index) in history" :key="index">
          <td>{{ new Date(game.date).toLocaleString() }}</td>
          <td>{{ game.attempts }}</td>
          <td>{{ game.time }}s</td>
          <td>{{ game.difficulty }}s</td>
          <td>{{ game.won ? 'Wygrana' : 'Przegrana' }}</td>
        </tr>
      </tbody>
    </table>
    <button @click="closeHistory">Zamknij</button>
  </div>
</template>

<script>
export default {
  props: {
    history: {
      type: Array,
      required: true
    }
  },
  methods: {
    closeHistory() {
      this.$emit('close'); // Emituje zdarzenie do zamknięcia historii
    }
  }
}
</script>

<style scoped>
.game-history {
  /* Stylizacja tabeli i przycisku */
  text-align: center; /* Wyśrodkowanie tekstu w kontenerze */
}

table {
  margin: 0 auto; /* Wyśrodkowanie tabeli */
}
</style>
