<template>
  <div class="m-card"
    :class="{
      '-active': cardInfo.flip,
      '-valid': cardInfo.valid,
      '-error': cardInfo.error
    }"
  >
    <div class="m-card_side -front">
      <canvas ref="frontCanvas" width="150" height="150"></canvas>
    </div>
    <div class="m-card_side -back">
      <canvas ref="backCanvas" width="150" height="150"></canvas>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
  props: { card: Object },
  data () {
    return {}
  },
  computed: {
    ...mapGetters(['getCard']),
    cardInfo () {
      return this.getCard(this.card.slug)
    }
  },
  mounted() {
    this.drawCanvas();
  },
  methods: {
    drawMultilineText(ctx, text, x, y, maxWidth, lineHeight) {
      const words = text.split(' ');
      let line = '';

      for (let n = 0; n < words.length; n++) {
        const testLine = line + words[n] + ' ';
        const metrics = ctx.measureText(testLine);
        const testWidth = metrics.width;

        if (testWidth > maxWidth && n > 0) {
          ctx.fillText(line, x, y);
          line = words[n] + ' ';
          y += lineHeight; // Move to the next line
        } else {
          line = testLine;
        }
      }
      ctx.fillText(line, x, y); // Draw the last line
    },
    drawCanvas() {
      const frontCanvas = this.$refs.frontCanvas;
      const backCanvas = this.$refs.backCanvas;
      const frontCtx = frontCanvas.getContext('2d');
      const backCtx = backCanvas.getContext('2d');

      // Ensure both canvases have the same dimensions
      const canvasWidth = 200; // Set the desired width
      const canvasHeight = 200; // Set the desired height
      frontCanvas.width = canvasWidth;
      frontCanvas.height = canvasHeight;
      backCanvas.width = canvasWidth;
      backCanvas.height = canvasHeight;

      // Load front image and set it as the first frame
      const frontImage = new Image();
      frontImage.src = '../../img/empty-card.png';
      frontImage.onload = () => {
        frontCtx.drawImage(frontImage, 0, 0, frontCanvas.width, frontCanvas.height);
        
        // Draw text on the front canvas using Montserrat
        frontCtx.fillStyle = 'gray'; // Set text color to gray
        frontCtx.font = 'bold 12px "Montserrat", sans-serif'; // Use Montserrat font
        frontCtx.textAlign = 'center'; // Center the text
        frontCtx.fillText('Ukryta karta', frontCanvas.width / 2, frontCanvas.height / 2 - 10); // Draw first text
        frontCtx.fillStyle = 'red';
        frontCtx.font = 'bold 22px "Montserrat", sans-serif'; // Use Montserrat font
        frontCtx.fillText('ODKRYJ', frontCanvas.width / 2, frontCanvas.height / 2 + 20); // Draw second text
      };
      frontImage.onerror = () => {
        console.error('Failed to load front image:', frontImage.src);
      };
      console.log('[this.cardInfo] ', this.cardInfo)
      // Load back image
      const backImage = new Image();
      backImage.src = '../../img/empty-card.png';
      backImage.onload = () => {
        backCtx.drawImage(backImage, 0, 0, backCanvas.width, backCanvas.height);
        
        // Draw text on the back canvas
        backCtx.fillStyle = this.cardInfo.rarity; // Set text color to white
        backCtx.font = '16px Arial'; // Set font size and family
        backCtx.textAlign = 'center'; // Center the text
        
        // Use the new multiline text drawing function
        const maxWidth = backCanvas.width - 20; // Set max width for text
        const lineHeight = 20; // Set line height
        
        // Create a gradient for the card image using this.cardInfo.rarity
        const gradient = backCtx.createLinearGradient(0, 0, 0, backCanvas.height);
        gradient.addColorStop(0, this.cardInfo.rarity + '80'); // Start color with 50% opacity
        gradient.addColorStop(1, this.cardInfo.rarity + '00'); // End color with 0% opacity

        // Set the global composite operation to 'source-atop' to apply the gradient
        backCtx.globalCompositeOperation = 'source-atop';
        backCtx.fillStyle = gradient;
        backCtx.fillRect(0, 0, backCanvas.width, backCanvas.height); // Fill the canvas with the gradient

        // Load and draw the cardInfo image centered on the back canvas
        const cardImage = new Image();
        cardImage.src = this.cardInfo.image; // Use the image from cardInfo
        cardImage.onload = () => {
          const imgWidth = 150; // Set desired width for the image
          const imgHeight = 150; // Set desired height for the image
          backCtx.drawImage(cardImage, (backCanvas.width - imgWidth) / 2, (backCanvas.height - imgHeight) / 2, imgWidth, imgHeight); // Draw centered image
        
          // Draw text on top of the image
          backCtx.fillStyle = this.cardInfo.rarity; // Set text color
          backCtx.font = '16px Arial'; // Set font size and family
          backCtx.textAlign = 'center'; // Center the text
        
          // Use the new multiline text drawing function
          const maxWidth = backCanvas.width - 20; // Set max width for text
          const lineHeight = 20; // Set line height
          this.drawMultilineText(backCtx, this.cardInfo.name, backCanvas.width / 2, (backCanvas.height - 30), maxWidth, lineHeight); // Draw card name on top of the image
        };
        cardImage.onerror = () => {
          console.error('Failed to load card image:', cardImage.src);
        };
      };
      backImage.onerror = () => {
        console.error('Failed to load back image:', backImage.src);
      };
    }
  }
}
</script>

<style lang="stylus">
  /* Import Montserrat font from Google CDN */
  @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500&display=swap');

  .m-card {
    font-family: 'Montserrat', sans-serif; // Apply Montserrat font
    height: 200px; // Increased height
    width: 200px; // Increased width
    padding: 10px;
    display: flex;
    justify-content: center;
    align-items: center;
    cursor: pointer;
    position: relative;
    color: var(--color-red);
    perspective: 150em;
    transition: transform 0.3s ease; // Add transition for smooth effect
    z-index: 10;
    &:hover {
      transform: translateY(-10px) scale(1.05); // Move up and scale on hover
    }

    &.-error {
      animation: shake 0.82s cubic-bezier(.36,.07,.19,.97) both;
      transform: translate3d(0, 0, 0);
      backface-visibility: hidden;
      perspective: 1000px;
    }

    &.-valid {
      border-color: white;
      color: white;
    }

    &.-active {
      .m-card_side.-front {
        transform: rotateY(-180deg);
      }

      .m-card_side.-back {
        transform: rotateY(0);
      }
    }

    img {
      max-width: 100%;
    }
  }

  .m-card_side {
    position: absolute;
    top: 1px;
    left: 1px;
    bottom: 1px;
    right: 1px;
    transition: transform .6s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    background: var(--color-base);
    backface-visibility: hidden;

    &.-front {
    }

    &.-back {
      transform: rotateY(180deg);
    }
  }

  @keyframes shake {
  10%, 90% {
    transform: translate3d(-1px, 0, 0);
  }

  20%, 80% {
    transform: translate3d(2px, 0, 0);
  }

  30%, 50%, 70% {
    transform: translate3d(-4px, 0, 0);
  }

  40%, 60% {
    transform: translate3d(4px, 0, 0);
  }
}
</style>

