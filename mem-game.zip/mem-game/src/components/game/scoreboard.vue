<template>
  <div class="m-score">
    <div class="m-score_items">
      <SkewButton class="m-score_item"><span>Rozgryki: </span> {{ plays }}</SkewButton>
      <SkewButton class="m-score_item"><span>Punkty:</span> {{ points }}</SkewButton>
      <SkewButton class="m-score_item"><span>Czas: </span> {{ time }}s</SkewButton>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import SkewButton from '../skew-button.vue'
import pageEnum from '../../enums/page'

export default {
  components: {
    SkewButton
  },
  computed: {
    ...mapGetters(['points', 'plays', 'time'])
  }
}
</script>

<style lang="stylus">
  .m-score_title {
    margin-top: 0;
    margin-bottom: var(--gutter-base);
  }

  .m-score_items {
    position: relative;
    display: flex;
    align-items center;
    justify-content: space-between;
  }

  .m-score_item {
    min-width: calc(25% - var(--gutter-base));
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 0;
    margin-bottom: 0;
    padding: var(--gutter-base);
    border: 1px solid var(--color-red);
    transform: skewX(-10deg);

    &:not(:last-child) {
      margin-right: var(--gutter-base);
    }
  }
</style>
