<template>
  <div class="m-controls">
    <div class="m-controls_controls">
      <SkewButton @click.native="resetData" class="m-controls_button">Zresetuj</SkewButton>
      <SkewButton @click.native="reset" class="m-controls_button">Wyjdź</SkewButton>
    </div>
  </div>
</template>

<script>
import { mapMutations } from 'vuex'
import SkewButton from '../skew-button.vue'

export default {
  components: {
    SkewButton
  },
  methods: {
    ...mapMutations(['reset', 'resetData'])
  }
}
</script>

<style lang="stylus">
  .m-controls_title {
    margin-top: 0;
    margin-bottom: var(--gutter-base);
  }

  .m-controls_button {
    &:not(:last-child) {
      margin-right: var(--gutter-base);
    }
  }
</style>
