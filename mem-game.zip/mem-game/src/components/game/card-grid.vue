<template>
  <div class="m-grid-card">
    <ul class="m-grid-card_cards" :class="difficultyClass">
      <li v-for="(item, idx) in cards" :key="idx">
        <card @click.native="flip(item)" :card="item" />
      </li>
    </ul>
  </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex'
import card from './card.vue'

export default {
  components: {
    card
  },
  computed: {
    ...mapGetters(['cards', 'difficulty']),
    difficultyClass() {
      return {
        'difficulty-easy': this.difficulty === 'Easy',
        'difficulty-medium': this.difficulty === 'Medium',
        'difficulty-hard': this.difficulty === 'Hard'
      }
    }
  },
  methods: {
    ...mapActions(['move']),
    flip (card) {
      this.move(card)
    }
  }
}
</script>

<style lang="stylus">
  .m-grid-card_title {
    margin-top: 0;
    margin-bottom: var(--gutter-base);
  }

  .m-grid-card_cards {
    list-style: none;
    padding-left: 0;
    display: grid;
    column-gap: var(--gutter-base);
    row-gap: var(--gutter-base);
    z-index: 10;
  }

  .difficulty-easy {
    grid-template-columns: repeat(3, 1fr); // Easy
  }

  .difficulty-medium {
    grid-template-columns: repeat(4, 1fr); // Medium
  }

  .difficulty-hard {
    grid-template-columns: repeat(5, 1fr); // Hard
  }

  // Add responsive styles
  @media (max-width: 768px) {
    .m-grid-card_cards {
      grid-template-columns: repeat(3, 1fr); // Adjust for tablets
    }
  }

  @media (max-width: 480px) {
    .m-grid-card_cards {
      grid-template-columns: repeat(2, 1fr); // Adjust for mobile phones
    }
  }
</style>
