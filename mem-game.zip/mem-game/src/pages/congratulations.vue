<template>
  <div class="congratulations">
    <img src="https://media.giphy.com/media/qXR53U25GPeocwivdd/giphy.gif" alt="Money Printer Go Brrr!" />
    <h1>Gratulacje!</h1>
    <p>Wygrałeś grę!</p>
    <button @click="goToMainMenu">Wróć do menu głównego</button>
  </div>
</template>

<script>
import { mapActions } from 'vuex'
import pageEnum from '../enums/page' // Import pageEnum

export default {
  name: 'congratulations',
  mounted() {
    console.log('Congratulations page is now visible');
  },
  methods: {
    ...mapActions(['changePage']), // Map the changePage action
    goToMainMenu() {
      this.changePage(pageEnum.START); // Change the page to START using Vuex
    }
  }
}
</script>

<style scoped>
.congratulations {
  text-align: center;
  margin-top: 50px;
}
</style>
