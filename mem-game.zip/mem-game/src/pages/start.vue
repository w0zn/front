<template>
  <div class="m-start">
    <Title class="m-start_title" />
    <ChooseDifficulty />
    <Button @click.native="onClick">Zagraj</Button>
    <Button @click.native="showHistory = true">Pokaż Historię Gier</Button> <!-- Przycisk do wyświetlania historii -->
    
    <GameHistory v-if="showHistory" :history="gameHistory" @close="showHistory = false" /> <!-- Tabela historii gier -->
  </div>
</template>

<script>
import { mapMutations, mapState, mapActions } from 'vuex'
import pageEnum from '../enums/page'
import Button from '../components/button.vue'
import Title from '../components/title.vue'
import ChooseDifficulty from '../components/choose-difficulty.vue'
import GameHistory from '../components/GameHistory.vue' // Import komponentu historii gier

export default {
  components: {
    Button,
    Title,
    ChooseDifficulty,
    GameHistory // Dodaj komponent do listy komponentów
  },
  data() {
    return {
      showHistory: false // Stan do zarządzania widocznością historii gier
    }
  },
  computed: {
    ...mapState(['gameHistory']) // Mapuj stan historii gier
  },
  methods: {
    ...mapMutations(['changePage', 'recalculateCards']),
    ...mapActions(['loadGameHistory']), // Mapuj akcję loadGameHistory
    onClick() {
      this.recalculateCards();
      this.changePage(pageEnum.GAME);
    },
  },
  created() {
    this.loadGameHistory(); // Load game history when the component is created
  },
}
</script>

<style lang="stylus">
  .m-start {
    text-align: center;
  }

  .m-start_title {
    margin-bottom: 0;
  }
</style>
