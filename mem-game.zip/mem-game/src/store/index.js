import { createStore } from 'vuex' // Updated import
import pageEnum from '../enums/page'
import getRandomCards from '../utils/getRandomCards' // Updated import
import { shuffle, duplicate } from '../utils/index'

const getResult = (arr) => (arr[0].name === arr[1].name)

const getDefaultData = (state, difficulty) => ({ // Accept difficulty as a parameter
  difficulty: difficulty || 'Easy', // Set difficulty based on parameter or default to 'Easy'
  cards: duplicate(getRandomCards(difficulty).cards.map(card => ({ // Use difficulty for getRandomCards
    ...card,
    flip: false,
    valid: false,
    error: false
  }))),
  points: 0,
  plays: 0,
  time: 60,
  timer: null,
})

const getDefaultState = (state) => ({
  ...getDefaultData(state), // Pass state to getDefaultData
  node: 'development',
  page: pageEnum.START
})

const getters = {
  difficulty: (state) => state.difficulty,
  cards: (state) => shuffle(state.cards),
  node: (state) => state.node,
  getCard: (state) => (cardSlug) => state.cards.find(card => card.slug === cardSlug),
  flippedCards: (state) => state.cards.filter(card => card.flip && !card.valid),
  points: (state) => state.points,
  plays: (state) => state.plays,
  page: (state) => state.page,
  time: (state) => state.time,
  timer: (state) => state.timer,
}

const mutations = {
  flipCards (state, cards) {
    state.cards.forEach(card => {
      const cd = cards.find(cds => cds.slug === card.slug)
      if (cd && !cd.valid) {
        card.flip = !card.flip
        // Play sound effect for flipping a card
        const flipSound = new Audio('sfx/cardFlip.mp3'); // Update with the correct path
        flipSound.play();
      }
    })
  },
  validateCards (state, cards) {
    state.cards.forEach(card => {
      const cd = cards.find(cds => cds.slug === card.slug)
      if (cd) {
        card.valid = !card.valid
      }
    })
  },
  incrementPoints (state) {
    state.points += 1
  },
  incrementPlays (state) {
    state.plays += 1
  },
  startTime (state) {
    state.timer = setInterval(() => {
      if (state.time > 0) {
        state.time -= 1
      } else {
        clearInterval(state.timer)
      }
    }, 1000)
  },
  breakTimer (state) {
    clearInterval(state.timer)
  },
  changeErrorCard (state, card) {
    const foundCard = state.cards.find((cd) => cd.slug === card.slug)
    foundCard.error = !foundCard.error
  },
  changePage (state, page) {
    state.page = page
  },
  reset (state) {
    clearInterval(state.timer)

    const s = getDefaultState(state) // Pass state to getDefaultState
    Object.keys(s).forEach((key) => { state[key] = s[key] })
  },
  resetData (state) {
    clearInterval(state.timer)

    const s = getDefaultData(state, state.difficulty); // Pass current difficulty to getDefaultData
    Object.keys(s).forEach((key) => { state[key] = s[key] });
  },
  setDifficulty(state, difficulty) {
    state.difficulty = difficulty; // Mutation to set difficulty level
    // Call resetData using commit
    state.resetData(); // Call resetData directly
  },
  recalculateCards(state) {
    const s = getDefaultData(state, state.difficulty); // Get default data with current difficulty
    state.cards = s.cards; // Update cards in the state
  },
  setWon(state, value) {
    state.won = value; // Mutation to set the won state
    if (value) {
      // Use commit to change the page
      state.page = pageEnum.CONGRATULATIONS; // Navigate to the congratulations page
    }
  },
  addGameToHistory(state, gameData) {
    const existingHistory = JSON.parse(localStorage.getItem('gameHistory')) || []; // Retrieve existing history
    existingHistory.push(gameData); // Add new game data to existing history
    state.gameHistory = existingHistory; // Update state with the new history
    localStorage.setItem('gameHistory', JSON.stringify(state.gameHistory)); // Save updated history to localStorage
  },
  loadGameHistory(state, history) {
    state.gameHistory = history; // Set the loaded history in the state
  },
}

const actions = {
  move ({ commit, getters, dispatch }, card) {
    let activeCards = getters.flippedCards

    if (activeCards.length === 2) {
      dispatch('irregularMovement', card)
    } else if (activeCards.length === 1 && activeCards[0].slug === card.slug) {
      dispatch('irregularMovement', card)
    } else {
      commit('flipCards', [card])
      activeCards = getters.flippedCards
      setTimeout(() => {
        if (activeCards.length === 2) {
          commit('incrementPlays')

          if (getResult(activeCards)) {
            commit('incrementPoints')
            commit('validateCards', activeCards)
            // Play sound effect for successful pairing
            const successSound = new Audio('sfx/match.mp3'); // Update with the correct path
            successSound.play();
          } else {
            commit('flipCards', activeCards)
          }
        }
        
        // Check if all cards are valid after each move
        if (getters.cards.every(card => card.valid)) {
          commit('setWon', true); // Set won state to true if all cards are valid
          console.log('[WWWWOOOON]')
          const gameData = {
            date: new Date().toISOString(), // Data zakończenia gry
            attempts: state.plays, // Liczba prób
            time: new Date().toISOString() + (60 - state.time), // Czas gry
            difficulty: state.difficulty,
            won: true, // Czy gra została wygrana
          };
          commit('addGameToHistory', gameData); // Zapisz dane gry w historii  
          commit('endGame');     
        }
      }, 600)
    }
  },
  irregularMovement ({ commit }, card) {
    commit('changeErrorCard', card)

    setTimeout(() => {
      commit('changeErrorCard', card)
    }, 2000)
  },
  endGame({ commit, state }) {
    const gameData = {
      date: new Date().toISOString(), // Data zakończenia gry
      attempts: state.plays, // Liczba prób
      time: state.time, // Czas gry
      difficulty: state.difficulty,
      won: state.won, // Czy gra została wygrana
    };
    commit('addGameToHistory', gameData); // Zapisz dane gry w historii
  },
  loadGameHistory({ commit }) {
    console.log('ladowanie historii')
    const history = localStorage.getItem('gameHistory');
    if (history) {
      commit('loadGameHistory', JSON.parse(history)); // Commit mutation to set the history in state
    } else {
      commit('loadGameHistory', []); // Ensure history is initialized as an empty array if not found
    }
  },
  retrieveGameHistoryFromLocalStorage({ commit }) {
    const history = localStorage.getItem('gameHistory');
    if (history) {
      commit('loadGameHistory', JSON.parse(history)); // Commit mutation to set the history in state
    } else {
      commit('loadGameHistory', []); // Ensure history is initialized as an empty array if not found
    }
  },
  changePage({ commit }, page) {
    commit('changePage', page); // Commit the mutation to change the page
  },
}

const state = {
  // ... existing state properties ...
  gameHistory: [], // Dodaj nową właściwość do przechowywania historii gier
  won: false, // Add won property to state
}

export default createStore({ // Updated store creation
  state: getDefaultState(),
  getters,
  mutations,
  actions
})
