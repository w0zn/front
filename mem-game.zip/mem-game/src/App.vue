<template>
  <div id="app">
    <Game />
    <img src="./assets/bg-detal.png" alt="bg detal" class="bg-detal">
  </div>
</template>

<script>
import Game from './components/game/root.vue'
import { mapGetters } from 'vuex'

export default {
  name: 'App',
  components: {
    Game
  },
  computed: {
    ...mapGetters(['node'])
  },
  created() {
    this.$store.dispatch('loadGameHistory'); // Dispatch the action to load game history
  }
}
</script>

<style lang="stylus">
:root {
  --color-base: #0f1923;
  --color-red: #ff4655;
  --gutter-base: 10px;
}

* {
  box-sizing border-box;
}

html {
  display: flex;
  flex-direction: column;
}

body {
  flex: 1;
}

html, body {
  min-height: 100%;
  margin: 0;
  padding: 0;
}

body {
  display flex;
  justify-content center;
  align-items center;
  flex-direction column;
  background: var(--color-base);
  color: white;
}

.bg-detal {
  display: none; // Hide by default
}

@media (min-width: 1280px) { // Adjust the min-width as per your tablet breakpoint
  .bg-detal {
    display: block; // Show when screen width is greater than tablet size
    position: fixed; // Keep the fixed positioning
    bottom: 0;
    right: 0;
    z-index: 1;
    overflow: hidden;
    max-width: 100%; // Prevent horizontal overflow
    height: auto; // Maintain aspect ratio
  }
}

h1, h2 {
  font-weight: normal;
}

#app
  font-family: 'Raleway', sans-serif;
  padding: 30px;


</style>
