import shuffleUtil from './shuffle'
import duplicateUtil from './duplicate'
import getRandomCards from './getRandomCards'

export default {
  shuffle: shuffleUtil,
  duplicate: duplicateUtil,
  getRandomCards: getRandomCards
}

export const shuffle = shuffleUtil
export const duplicate = duplicateUtil
export const randm = getRandomCards
