import { describe, it, expect } from 'vitest';
import duplicate from './duplicate';

describe('duplicate function', () => {
  it('should duplicate each object in the array and append "-copy" to the slug', () => {
    const input = [{ slug: 'item1' }, { slug: 'item2' }];
    const expectedOutput = [
      { slug: 'item1' },
      { slug: 'item1-copy' },
      { slug: 'item2' },
      { slug: 'item2-copy' },
    ];

    expect(duplicate(input)).toEqual(expectedOutput);
  });
});

