import getRandomCards from './getRandomCards';
import itemData from './all.json';

describe('getRandomCards', () => {
    it('should return 3 cards for Easy difficulty', () => {
        const result = getRandomCards('Easy');
        expect(result.cards.length).toBe(3);
        result.cards.forEach(card => {
            expect(card).toHaveProperty('name');
            expect(card).toHaveProperty('slug');
            expect(card).toHaveProperty('image');
            expect(card).toHaveProperty('rarity');
        });
    });

    it('should return 4 cards for Medium difficulty', () => {
        const result = getRandomCards('Medium');
        expect(result.cards.length).toBe(4);
    });

    it('should return 5 cards for Hard difficulty', () => {
        const result = getRandomCards('Hard');
        expect(result.cards.length).toBe(5);
    });

    it('should filter out items with undefined rarity color', () => {
        const result = getRandomCards('Easy');
        result.cards.forEach(card => {
            expect(card.rarity).toBeDefined();
        });
    });
});
