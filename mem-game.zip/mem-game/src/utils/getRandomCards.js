import itemData from './all.json'; // Import the local JSON file


function getRandomCards(difficulty = "Easy") {
    // Get all items from itemData
    const allItems = Object.values(itemData); // Convert itemData object to an array

    // Shuffle the array to randomize the order
    const shuffledItems = allItems.sort(() => 0.5 - Math.random());

    // Determine the number of items to select based on difficulty
    const numberOfItems = difficulty === 'Easy' ? 3 : difficulty === 'Medium' ? 4 : 5;

    // Select the items from the shuffled array based on the difficulty
    const selectedItems = shuffledItems.slice(0, numberOfItems);

    // Filter out items with undefined rarity color
    const validItems = selectedItems.filter(item => item.rarity && item.rarity.color !== undefined);

    return {
        cards: validItems.map(item => ({
            name: item.name,
            slug: item.id,
            image: item.image,
            rarity: item.rarity.color
        }))
    };
}

export default getRandomCards;
