import shuffle from './shuffle'

describe('shuffle function', () => {
  it('should shuffle the array', () => {
    const arr = [1, 2, 3, 4, 5]
    const shuffledArr = shuffle(arr)
    expect(shuffledArr).not.toEqual(arr) // Check that the array is shuffled
    expect(shuffledArr.sort()).toEqual(arr.sort()) // Check that it contains the same elements
  })

  it('should return an empty array when input is empty', () => {
    expect(shuffle([])).toEqual([])
  })
})

