
export default {
  START: 'start',
  GAME: 'game',
  CONGRATULATIONS: 'congratulations'
}
